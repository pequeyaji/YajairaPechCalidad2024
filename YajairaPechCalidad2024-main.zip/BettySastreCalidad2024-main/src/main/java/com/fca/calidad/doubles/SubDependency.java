package com.fca.calidad.doubles;


public class SubDependency {

	public String getClassName() {
		return this.getClass().getSimpleName();
	}
}
