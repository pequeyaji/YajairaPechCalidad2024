package com.fca.calidad.unitaria;

import static org.hamcrest.MatcherAssert.assertThat; 
import static org.hamcrest.Matchers.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class Calculadoratest {

	private double num1 = 0;
	private double num2 = 0;
	private Calculadora calculadora= null;
	@BeforeEach
	void setup() {
		num1 = 2;
		num2 = 5;
		calculadora = new Calculadora();
	}
	@Test
	void suma2numerosPositivosTest() {
		
		//Inicialización
	
		double resEsperado = 7;
		
		//Ejercicio, llamar al metodo que queremos provar 
		double resEjecucion = calculadora.suma(num1, num2);
		
		//verificar
		assertThat(resEsperado, is(resEjecucion));
		
	}

}
