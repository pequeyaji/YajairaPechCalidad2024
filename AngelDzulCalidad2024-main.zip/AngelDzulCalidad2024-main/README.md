# AngelDzulCalidad2024
retro de la clase de calidad
